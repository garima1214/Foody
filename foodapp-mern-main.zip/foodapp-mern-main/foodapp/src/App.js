import "./App.css";

function App() {
  return (
    <div className="App">
      <h1 className="bg-blue  font-primary">this is h1</h1>
    </div>
  );
}

export default App;
