import React from "react";

const useCart = () => {
  return <div>useCart</div>;
};

export default useCart;
